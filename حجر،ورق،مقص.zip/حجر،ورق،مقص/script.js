document.addEventListener("DOMContentLoaded", function() {
    const choices = ["حجر", "ورقة", "مقص"];
    let attempts = 3;
    let wins = 0;
    let losses = 0;
    let ties = 0;
    let highScore = 0;

    function playGame(userChoice) {
        if (attempts === 0) {
            alert("لقد انتهت المحاولات! انقر على 'إعادة اللعب' للبدء من جديد.");
            return;
        }

        const computerChoice = choices[Math.floor(Math.random() * choices.length)];
        let result;

        if (userChoice === computerChoice) {
            result = "تعادل!";
            updateScores(userChoice, computerChoice, "tie");
            ties++;
        } else {
            const winCondition = (userChoice === "حجر" && computerChoice === "مقص") ||
                                 (userChoice === "ورقة" && computerChoice === "حجر") ||
                                 (userChoice === "مقص" && computerChoice === "ورقة");

            result = winCondition ? "فوزت!" : "خسرت!";
            updateScores(userChoice, computerChoice, winCondition ? "win" : "lose");
            winCondition ? wins++ : losses++;
            winCondition ? attempts++ : attempts--;
        }

        updateAttemptsDisplay();
        updateHighScore();
    }

    function updateScores(userChoice, computerChoice, resultType) {
        setResultText(userChoice, computerChoice, resultType);
    }

    function setResultText(userChoice, computerChoice, resultType) {
        const resultElement = document.getElementById("result");
        const resultText = userChoice === computerChoice ? "تعادل!" : resultType === "win" ? "فوزت!" : "خسرت!";
        resultElement.textContent = `اخترت ${userChoice}، والكمبيوتر اختار ${computerChoice}. ${resultText}`;
        resultElement.className = `result-text ${resultType}`;
    }

    function updateAttemptsDisplay() {
        document.getElementById("attempts").textContent = `المحاولات المتبقية: ${attempts}`;
    }

    function updateHighScore() {
        if (wins > highScore) {
            highScore = wins;
        }
    }

    function resetGame() {
        attempts = 3;
        wins = 0;
        losses = 0;
        ties = 0;
        updateAttemptsDisplay();
        document.getElementById("result").textContent = "اختر حركتك!";
        document.getElementById("result").className = "result-text";
    }

    // Event listeners
    document.getElementById("rock").addEventListener("click", function() {
        playGame("حجر");
    });

    document.getElementById("paper").addEventListener("click", function() {
        playGame("ورقة");
    });

    document.getElementById("scissors").addEventListener("click", function() {
        playGame("مقص");
    });

    document.getElementById("reset").addEventListener("click", function() {
        resetGame();
    });

    document.getElementById("current-score").addEventListener("click", function() {
        alert(`النتيجة الحالية:\nالفوز: ${wins}\nالخسارة: ${losses}\nالتعادل: ${ties}`);
    });

    document.getElementById("high-score").addEventListener("click", function() {
        alert(`أعلى نتيجة: ${highScore}`);
    });
});